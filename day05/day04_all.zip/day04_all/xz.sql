#设置客户端连接服务器端编码
SET NAMES UTF8;
#丢弃数据库，如果存在
DROP DATABASE IF EXISTS xz;
#创建数据库，设置存储的编码
CREATE DATABASE xz CHARSET=UTF8;
#进入该数据库
USE xz;
#创建保存笔记本家族数据的表laptop_family
CREATE TABLE laptop_family(
  fid TINYINT PRIMARY KEY,
  fname VARCHAR(8) UNIQUE,
  #设置默认数量为5，分别使用两种方式插入数据
  laptopCount SMALLINT DEFAULT 5
);
#插入数据
INSERT INTO laptop_family VALUES(10,'联想',2);
INSERT INTO laptop_family VALUES(20,'戴尔',2);
INSERT INTO laptop_family VALUES(30,'苹果',1);
INSERT INTO laptop_family VALUES(40,'神州',DEFAULT);
INSERT INTO laptop_family(fid,fname) VALUES(50,'华硕');
#创建保存笔记本数据的表
CREATE TABLE laptop(
  lid INT PRIMARY KEY AUTO_INCREMENT,
  title VARCHAR(128) UNIQUE,
  price DECIMAL(7,2),  #99999.99
  spec VARCHAR(32),
  detail VARCHAR(3000) NOT NULL,
  shelfTime DATE DEFAULT '2018-10-1', #默认的上架时间 '2018-10-1'
  familyId TINYINT,
  FOREIGN KEY(familyId) REFERENCES laptop_family(fid)
);
#插入数据
INSERT INTO laptop VALUES(1,'ThinkPad E440',3899,'宗师版','详情内容1','2018-2-1',10);
INSERT INTO laptop VALUES(2,'Macbook Air',4899,'游戏版','详情内容2','2018-3-1',30);
INSERT INTO laptop VALUES(3,'戴尔灵越',3299,'枪弹版','详情内容2','2018-5-1',20);
INSERT INTO laptop VALUES(4,'Macbook Pro',8899,'旗舰版','详情内容4','2018-7-1',30);
INSERT INTO laptop VALUES(5,'戴尔燃7000',5429,DEFAULT,'详情内容5',DEFAULT,20);
INSERT INTO laptop(lid,title,price,spec,detail) VALUES(6,'联想超越',2999,'办公版','详细介绍6');
INSERT INTO laptop VALUES(7,'神州T800',5400,'吃鸡版','详情介绍7','2018-12-1',40);
INSERT INTO laptop VALUES(NULL,'外星人',12000,'超级游戏版','详情介绍8',DEFAULT,20);
INSERT INTO laptop VALUES(NULL,'外星人2',13000,'超级游戏版','详情介绍8',DEFAULT,20);
INSERT INTO laptop VALUES(NULL,'外星人3',11000,'超级游戏版','详情介绍8',DEFAULT,20);
INSERT INTO laptop VALUES(15,'外星人4',10000,'超级游戏版','详情介绍8',DEFAULT,20);
INSERT INTO laptop VALUES(NULL,'外星人5',8000,'超级游戏版','详情介绍8',DEFAULT,20);