#设置客户端连接服务器端编码
SET NAMES UTF8;
#丢弃数据库,如果存在
DROP DATABASE IF EXISTS tedu;
#创建数据库，设置存储的编码
CREATE DATABASE tedu CHARSET=UTF8;
#进入该数据库
USE tedu;
#创建保存部门数据的表
CREATE TABLE dept(
  did TINYINT PRIMARY KEY AUTO_INCREMENT,
  dname VARCHAR(8) UNIQUE
);
#插入数据
INSERT INTO dept VALUES(10,'研发部');
INSERT INTO dept VALUES(20,'市场部');
INSERT INTO dept VALUES(30,'运营部');
INSERT INTO dept VALUES(40,'测试部');
#创建保存员工数据的表
CREATE TABLE emp(
  eid SMALLINT PRIMARY KEY AUTO_INCREMENT,
  ename VARCHAR(6),
  sex BOOL,
  birthday DATE,
  salary DECIMAL(7,2),  #99999.99
  deptId TINYINT,
  FOREIGN KEY(deptId) REFERENCES dept(did)
);
#插入数据









